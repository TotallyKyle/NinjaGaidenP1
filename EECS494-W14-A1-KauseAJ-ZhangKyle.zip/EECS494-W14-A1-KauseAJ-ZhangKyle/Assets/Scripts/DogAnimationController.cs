﻿using UnityEngine;
using System.Collections;

public class DogAnimationController : AnimationController<Dog> {

	public override void UpdateAnimationState() {
	}
}
