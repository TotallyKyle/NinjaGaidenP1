﻿using UnityEngine;
using System.Collections;

public class FireWheelAnimationController : AnimationController<FireWheel> {

	public override void UpdateAnimationState() {
	}
}
